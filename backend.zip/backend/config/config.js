// config.js

module.exports = {
    secretKey: process.env.JWT_SECRET || "grfgrhe",
  };
  